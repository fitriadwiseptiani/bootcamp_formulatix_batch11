namespace MonopolyGame;

public class Player
{
    public int Id { get; private set; }
	public string Name { get; private set; }
}
