namespace MonopolyGame;

public class Dice
{
    public int NumberOfSides { get; private set; }
    public int SideValues[] { get; private set; }

    public Dice(int numberOfSides, int sideValues[]){
        
    }
    public int Roll(){
        
    }
}
