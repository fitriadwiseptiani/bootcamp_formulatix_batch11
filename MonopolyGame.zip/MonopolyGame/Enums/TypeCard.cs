namespace MonopolyGame;

public enum TypeCard
{
    CardChance,
    CardCommunity
}
