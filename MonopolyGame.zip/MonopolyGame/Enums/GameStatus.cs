namespace MonopolyGame;

public enum GameStatus
{
    Preparation,
    Play,
    End
}
