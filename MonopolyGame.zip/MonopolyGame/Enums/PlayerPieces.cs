namespace MonopolyGame;

public enum PlayerPieces
{
    Battleship,
	RaceCar,
	TopHat,
	Thimble,
	Shoe,
	ScottieDog,
	Iron,
	Wheelbarrow
}
