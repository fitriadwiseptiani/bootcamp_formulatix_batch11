namespace MonopolyGame;

public class Bank
{
    public decimal TotalBalance { get; private set; }

    public Bank(decimal totalBalance){

    }
    public bool UpdateMoney(IPlayer player, decimal amount)
    {

    }
    public bool PayToPlayer(IPlayer player, decimal amount){

    }
    public bool TakeMoneyFromPlayer(IPlayer player, decimal amount)
    {

    }
}
