namespace MonopolyGame;

public interface IDice
{
    public int NumberOfSides { get;}
    public int SideValues[] { get;}

    public int Roll(){
        
    }
}
